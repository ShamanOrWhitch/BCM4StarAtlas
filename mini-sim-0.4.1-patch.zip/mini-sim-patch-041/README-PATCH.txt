BCM Mini-Sim 0.4.1 patch
Replace these 3 files on the site (do not delete wall/portal/mp3/mp4):
  wp-content/plugins/mini-sim/bcm-mini-sim.php
  wp-content/plugins/mini-sim/assets/js/mini-sim.js
  wp-content/plugins/mini-sim/assets/css/mini-sim.css
Then purge LiteSpeed + Autoptimize cache.
