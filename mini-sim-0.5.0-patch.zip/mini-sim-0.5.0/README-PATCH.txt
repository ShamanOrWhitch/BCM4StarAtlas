Replace on the server:
  wp-content/plugins/mini-sim/bcm-mini-sim.php
  wp-content/plugins/mini-sim/assets/js/mini-sim.js
  wp-content/plugins/mini-sim/assets/css/mini-sim.css
Then purge LiteSpeed + Autoptimize.
HUD must say 0.5.0. If JS is still ~48890 bytes, the old file was not overwritten.
