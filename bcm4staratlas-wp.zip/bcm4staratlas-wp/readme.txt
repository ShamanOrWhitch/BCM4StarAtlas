=== BCM4StarAtlas Galia Bay ===
Requires at least: 6.0
Tested up to: 6.8
Stable tag: 1.0.0

== Установка ==

1. Залей zip через Плагины → Добавить новый → Загрузить
2. Активируй BCM4StarAtlas
3. На страницу добавь шорткод [bcm4staratlas]
4. galia.html не нужен. Блок «Произвольный HTML» из Архива не нужен.

== Шорткод ==

[bcm4staratlas]
[bcm4staratlas height="90vh"]
[galia]
