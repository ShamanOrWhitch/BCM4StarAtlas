<?php
/**
 * Plugin Name: Best Crew Missions 4 Star Atlas Simulator
 * Description: Подбор команды и флотов под миссию. Шорткод [bcm4staratlas]
 * Version: 1.1.0
 * Author: WalkingYog
 */

if (!defined('ABSPATH')) {
    exit;
}

define('BCM4SA_VER', '1.1.0');
define('BCM4SA_URL', plugin_dir_url(__FILE__));

add_action('admin_menu', function () {
    add_options_page('BCM4StarAtlas', 'BCM4StarAtlas', 'manage_options', 'bcm4staratlas', 'bcm4sa_settings_page');
});

add_action('admin_init', function () {
    register_setting('bcm4sa', 'bcm4sa_rpc');
});

function bcm4sa_settings_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }
    echo '<div class="wrap"><h1>Best Crew Missions 4 Star Atlas Simulator</h1>';
    echo '<p>На страницу вставь только: <code>[bcm4staratlas]</code></p>';
    echo '<p>galia.html не нужен. В Autoptimize исключи JS плагинов bcm4staratlas и mini-sim.</p>';
    echo '<form method="post" action="options.php">';
    settings_fields('bcm4sa');
    $rpc = esc_attr(get_option('bcm4sa_rpc', 'https://api.mainnet-beta.solana.com'));
    echo '<table class="form-table"><tr><th>Solana RPC</th><td>';
    echo '<input type="url" class="regular-text" name="bcm4sa_rpc" value="' . $rpc . '">';
    echo '</td></tr></table>';
    submit_button();
    echo '</form></div>';
}

add_shortcode('bcm4staratlas', 'bcm4sa_shortcode');
add_shortcode('galia', 'bcm4sa_shortcode');

function bcm4sa_shortcode($atts)
{
    $atts = shortcode_atts(['height' => '88vh'], $atts);
    wp_enqueue_style('bcm4sa', BCM4SA_URL . 'assets/app.css', [], BCM4SA_VER);
    wp_enqueue_script('bcm4sa', BCM4SA_URL . 'assets/app.js', [], BCM4SA_VER, true);
    wp_localize_script('bcm4sa', 'BCM4SA', [
        'ajax' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('bcm4sa'),
    ]);
    $h = esc_attr($atts['height']);
    return '<div id="bcm4sa-root" class="bcm4sa" style="min-height:' . $h . '"></div>';
}

add_filter('autoptimize_filter_js_exclude', function ($exclude) {
    return $exclude . ', bcm4staratlas/assets/app.js, mini-sim/assets/js/mini-sim.js, three.min.js';
});

add_action('wp_ajax_bcm4sa_prices', 'bcm4sa_prices');
add_action('wp_ajax_nopriv_bcm4sa_prices', 'bcm4sa_prices');

function bcm4sa_prices()
{
    $nonce = isset($_REQUEST['_wpnonce']) ? sanitize_text_field(wp_unslash($_REQUEST['_wpnonce'])) : '';
    if (!wp_verify_nonce($nonce, 'bcm4sa')) {
        wp_send_json_error('nonce', 403);
    }
    $ids = isset($_POST['ids']) ? sanitize_text_field(wp_unslash($_POST['ids'])) : '';
    if ($ids === '') {
        wp_send_json_error('ids', 400);
    }
    $res = wp_remote_get('https://lite-api.jup.ag/price/v2?ids=' . rawurlencode($ids), ['timeout' => 20]);
    if (is_wp_error($res)) {
        wp_send_json_error($res->get_error_message(), 502);
    }
    wp_send_json_success(json_decode(wp_remote_retrieve_body($res), true));
}
