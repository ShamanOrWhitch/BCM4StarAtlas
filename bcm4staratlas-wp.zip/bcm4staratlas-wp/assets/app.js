(function () {
  "use strict";

  var CREW = [
    { id: "koben", name: "Koben", role: "кэп", ship: "Jetjet-1", apt: "Command" },
    { id: "seraimal", name: "Seraimal", role: "штурвал", ship: "Jetjet-1", apt: "Flight" },
    { id: "shimadair", name: "Shimadair", role: "штурвал", ship: "Jetjet-2", apt: "Flight" },
    { id: "takedaani", name: "Takedaani", role: "медик", ship: "Jetjet-2", apt: "Medical" },
    { id: "uusathar", name: "Uusathar", role: "штурвал", ship: "Jetjet-3", apt: "Flight" },
    { id: "urtelaorilve", name: "Urtelaorilve", role: "оператор", ship: "Jetjet-3", apt: "Operator" },
    { id: "viurneca", name: "Viurneca", role: "штурвал", ship: "Проба-1", apt: "Flight" },
    { id: "yarrindilpho", name: "Yarrindilpho", role: "оператор", ship: "Проба-1", apt: "Operator" },
    { id: "ooniseth", name: "Ooniseth", role: "оператор", ship: "Jetjet Ooniseth", apt: "Operator" },
    { id: "arsamehafa", name: "Arsamehafa", role: "штурвал", ship: "Jetjet Ooniseth", apt: "Flight" },
    { id: "deceon", name: "Deceon", role: "оператор", ship: "Tufa", apt: "Operator" },
    { id: "tavia", name: "Tavia", role: "наука", ship: "Tufa", apt: "Science" },
    { id: "pricer", name: "Pricer", role: "пилот", ship: "Chi", apt: "Flight" },
    { id: "enyavana", name: "Enyavana", role: "пилот", ship: "Airbike-1", apt: "Flight" },
    { id: "raurtawa", name: "Raurtawa", role: "инж", ship: "CSS", apt: "Engineering" },
    { id: "phulelonva", name: "Phulelonva", role: "инж", ship: "CSS", apt: "Engineering" },
    { id: "elizondo", name: "Elizondo", role: "камбуз", ship: "CSS", apt: "Hospitality" },
    { id: "anbeloon", name: "Anbeloon", role: "медик", ship: "CSS", apt: "Medical" }
  ];

  var FLEETS = [
    {
      id: "edge",
      name: "Кромка UNI",
      ships: ["Jetjet-1", "Jetjet-2", "Jetjet-3", "Проба-1", "Ooniseth", "Airbike x5"],
      crew: ["koben", "seraimal", "shimadair", "takedaani", "uusathar", "urtelaorilve", "viurneca", "yarrindilpho", "ooniseth", "arsamehafa", "enyavana"],
      lamp: "green",
      job: "Лампа-1 SZ"
    },
    {
      id: "ambush",
      name: "Засада Chi",
      ships: ["Chi", "Tufa"],
      crew: ["pricer", "deceon", "tavia"],
      lamp: "yellow",
      job: "Ioki / орбита пояса"
    },
    {
      id: "css",
      name: "CSS hab",
      ships: ["станция"],
      crew: ["raurtawa", "phulelonva", "elizondo", "anbeloon"],
      lamp: "green",
      job: "отдых / ремонт"
    }
  ];

  var MISSIONS = [
    {
      id: "lamp1",
      name: "Лампа-1 · SZ патруль",
      fleets: ["edge"],
      need: "Jetjet + байки, 2 слота Flight/Operator",
      fuel: 400,
      food: 40,
      ammo: 80,
      tools: 10,
      note: "Кромка ONI CSS. Не MRZ."
    },
    {
      id: "belt",
      name: "Пояс · 2 на орбите + Chi в засаде",
      fleets: ["edge", "ambush"],
      need: "15 корпусов не надо: 2 джета на орбите, Chi прячется",
      fuel: 900,
      food: 80,
      ammo: 220,
      tools: 24,
      note: "Прикрытие баржи / пиратский сектор."
    },
    {
      id: "om",
      name: "Om · жирный рейс",
      fleets: ["ambush"],
      need: "Rainbow Om аренда, 4 слота",
      fuel: 4000,
      food: 200,
      ammo: 100,
      tools: 40,
      note: "Не в собственность."
    },
    {
      id: "rest",
      name: "Hab · простой",
      fleets: ["css"],
      need: "инж + камбуз + госпиталь",
      fuel: 0,
      food: 20,
      ammo: 0,
      tools: 8,
      note: "Малый флот отдыхает."
    }
  ];

  var R4 = [
    { name: "Fuel", mint: "fueL3hBZjLLLJHiFH9cqZoozTG3XQZ53diwFPwbzNim" },
    { name: "Food", mint: "foodQJAztMzX1DKpLaiounNe2BDMds5RNuPC6jsNrDG" },
    { name: "Ammo", mint: "ammoK8AkX2wnebQb35cDAZtTkvsXQbi82cGeTnUvvfK" },
    { name: "Toolkit", mint: "tooLsNYLiVqzg8o4m3L2Uetbn62mvMWRqkog6PQeYKL" }
  ];
  var ATLAS = "ATLASXmbPQxBUYbxPsV97usA3fPQYEqzQBUHgiFCUsXx";

  var state = { tab: "crew", prices: {}, mission: "belt" };

  function el(html) {
    var d = document.createElement("div");
    d.innerHTML = html;
    return d.firstElementChild;
  }

  function lamp(color) {
    var map = { green: "на месте", yellow: "в пути", red: "опасность / нет ресурса" };
    return '<span class="bcm-lamp bcm-lamp-' + color + '" title="' + map[color] + '"></span>';
  }

  function crewById(id) {
    for (var i = 0; i < CREW.length; i++) if (CREW[i].id === id) return CREW[i];
    return { name: id, role: "", ship: "", apt: "" };
  }

  function postPrices() {
    if (!window.BCM4SA) return Promise.resolve();
    var ids = [ATLAS].concat(R4.map(function (r) { return r.mint; })).join(",");
    var body = new URLSearchParams({ action: "bcm4sa_prices", _wpnonce: BCM4SA.nonce, ids: ids });
    return fetch(BCM4SA.ajax, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: body })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        var data = (j.data && j.data.data) || {};
        var prices = {};
        Object.keys(data).forEach(function (k) { prices[k] = Number(data[k].price || 0); });
        state.prices = prices;
      })
      .catch(function () {});
  }

  function usd(n) {
    if (!n) return "—";
    return n < 0.01 ? "$" + n.toFixed(5) : "$" + n.toFixed(3);
  }

  function cost(m) {
    var qty = [m.fuel, m.food, m.ammo, m.tools];
    var sum = 0;
    var rows = R4.map(function (r, i) {
      var tot = (state.prices[r.mint] || 0) * qty[i];
      sum += tot;
      return { name: r.name, qty: qty[i], tot: tot };
    });
    return { rows: rows, sum: sum };
  }

  function render() {
    var root = document.getElementById("bcm4sa-root");
    if (!root) return;
    root.innerHTML = "";
    var wrap = el('<div class="bcm-wrap"></div>');
    wrap.appendChild(header());
    wrap.appendChild(body());
    root.appendChild(wrap);
    bind(root);
  }

  function header() {
    var h = el('<div class="bcm-top"></div>');
    h.innerHTML =
      '<div><p class="bcm-k">Best Crew Missions 4 Star Atlas Simulator</p>' +
      "<h1>Подбор команды под миссию</h1></div>" +
      '<nav class="bcm-nav">' +
      btn("crew", "Команда") +
      btn("fleets", "Флоты") +
      btn("missions", "Миссии") +
      btn("calc", "R4") +
      "</nav>";
    return h;
  }

  function btn(id, label) {
    return '<button type="button" data-tab="' + id + '" class="' + (state.tab === id ? "on" : "") + '">' + label + "</button>";
  }

  function body() {
    var b = el('<div class="bcm-main"></div>');
    if (state.tab === "fleets") b.innerHTML = fleetsHtml();
    else if (state.tab === "missions") b.innerHTML = missionsHtml();
    else if (state.tab === "calc") b.innerHTML = calcHtml();
    else b.innerHTML = crewHtml();
    return b;
  }

  function crewHtml() {
    var rows = CREW.map(function (c) {
      return "<tr><td>" + c.name + "</td><td>" + c.role + "</td><td>" + c.apt + "</td><td>" + c.ship + "</td></tr>";
    }).join("");
    return (
      "<p class=\"bcm-note\">Каталог уже внесённых пакетов. Кошелёк подключим отдельным шагом. Цель — собрать лучшую команду под миссию, в том числе из нескольких флотов.</p>" +
      "<table><thead><tr><th>Имя</th><th>Роль</th><th>Apt</th><th>Борт</th></tr></thead><tbody>" +
      rows +
      "</tbody></table>"
    );
  }

  function fleetsHtml() {
    return FLEETS.map(function (f) {
      var people = f.crew.map(function (id) { return crewById(id).name; }).join(", ");
      return (
        '<article class="bcm-card"><div class="p">' +
        lamp(f.lamp) +
        " <b>" + f.name + "</b>" +
        '<p class="bcm-meta">' + f.job + " · " + f.ships.join(" · ") + "</p>" +
        "<p>" + people + "</p></div></article>"
      );
    }).join("");
  }

  function missionsHtml() {
    return MISSIONS.map(function (m) {
      var fl = m.fleets.map(function (id) {
        for (var i = 0; i < FLEETS.length; i++) if (FLEETS[i].id === id) return lamp(FLEETS[i].lamp) + " " + FLEETS[i].name;
        return id;
      }).join("<br>");
      var c = cost(m);
      var rows = c.rows.map(function (r) {
        return "<tr><td>" + r.name + "</td><td>" + r.qty + "</td><td>" + usd(r.tot) + "</td></tr>";
      }).join("");
      return (
        '<article class="bcm-card"><div class="p"><h3>' + m.name + "</h3>" +
        '<p class="bcm-note">' + m.note + "</p>" +
        '<p class="bcm-meta">' + m.need + "</p>" +
        "<p>" + fl + "</p>" +
        "<table><tbody>" + rows + "<tr><td colspan=\"2\">Итого рынок</td><td>" + usd(c.sum) + "</td></tr></tbody></table>" +
        "</div></article>"
      );
    }).join("");
  }

  function calcHtml() {
    var rows = [{ name: "ATLAS", mint: ATLAS }].concat(R4).map(function (r) {
      return "<tr><td>" + r.name + "</td><td>" + usd(state.prices[r.mint]) + "</td></tr>";
    }).join("");
    return "<p class=\"bcm-note\">Цены Jupiter USD. Баки / карго / scan возьмём из Galaxy slots при следующем обновлении каталога на GitHub.</p><table>" + rows + "</table>";
  }

  function bind(root) {
    var tabs = root.querySelectorAll("[data-tab]");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].addEventListener("click", function (ev) {
        state.tab = ev.currentTarget.getAttribute("data-tab");
        render();
      });
    }
  }

  function boot() {
    render();
    postPrices().then(render);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
